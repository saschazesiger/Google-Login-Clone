from django.contrib import admin
from Phisher.models import SignIn

# Models
admin.site.register(SignIn)
